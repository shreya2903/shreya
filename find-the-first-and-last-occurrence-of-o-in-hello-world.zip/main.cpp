/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
#include<cstring>
using namespace std;
int main(){
    string str= "hello world";
    
    char ch='o';
    for(int i=0;i<str.length();i++){
        if(str[i]==ch){
            cout<<i<<endl;
            break;
        }
    }
    for(int j=(str.length()-1);j>=0;j--){
        if(str[j]==ch){
            cout<<j<<endl;
            break;
        }
    }
    return 0;
}
