/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include<iostream>
using namespace std;

int main()
{
    int a[10];
    int i,j;
    for(i=0;i<5;i++){
        cin>>a[i];
    }
    j=i-1;
    i=0;
    int flag=0;
    while(i<j){
        if(a[i]==a[j]){
          i++;
          j--;
          flag++;
          break;
        }
        else
         break;
         }
     if(flag>0){
         cout<<"yes";
     }
     else
     cout<<"no";
     
    return 0;
}
