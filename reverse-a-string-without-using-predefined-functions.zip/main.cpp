/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<string>
using namespace std;

int main()
{
    string s1="abcd";
    string s2;
    s2.resize(s1.length());
    for(int i=0;i<s1.length();i++){
        s2[s1.length()-i-1]=s1[i];
        
    }
    cout<<s2<<endl;

    return 0;
}

