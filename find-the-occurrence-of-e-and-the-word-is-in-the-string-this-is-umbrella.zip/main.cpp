/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<cstring>
using namespace std;

int main()
{
    string s1="This is umbrella";
    
    char ch='e';
    
    for(int i=0;i<s1.length();i++){
        if(s1[i]==ch){
            cout<<i<<endl;
        }
    }
    for(int i=0;i<s1.length();i++){
        if(s1[i]=='i'&& s1[i+1]=='s'){
            cout<<i<<endl;
        }
    }

    return 0;
}