/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int main()
{
    int a,b,c;
    int *x,*y,*z;
    cin>>a;
    cin>>b;
    cin>>c;
    x=&a;
    y=&b;
    z=&c;
    if(a>b&&a>c)
    cout<<"the greatest no. is: "<<*x<<endl;
    else if(b>a&&b>c)
    cout<<"the greatest no. is: "<<*y<<endl;
    else
    cout<<"the greatest no. is: "<<*z<<endl;
    if(a<b&&a<c)
    cout<<"the smallest no. is: "<<*x<<endl;
    else if(b<a&&b<c)
    cout<<"the smallest no. is: "<<*y<<endl;
    else
    cout<<"the smallest no. is: "<<*z<<endl;
    

    return 0;
}
