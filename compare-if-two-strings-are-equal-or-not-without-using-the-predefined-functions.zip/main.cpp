/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<string>
using namespace std;

int main()
{
    string x,y;
    cin>>x;
    cin>>y;
    bool equal= true;
    if(x.length()!=y.length()){
        equal=false;
    }
    else
    {
        for(int i=0;i<x.length();i++){
            if(x[i]!=y[i]){
                equal=0;
                break;
            }
        }
    }
    if(equal>0){
        cout<<"true";
    }
   else
   cout<<"false";
    return 0;
}

