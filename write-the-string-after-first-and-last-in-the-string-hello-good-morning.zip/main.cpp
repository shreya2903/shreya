/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<string>
using namespace std;
int main()
{
    
    string str="Hello, good, morning";
    int first,last;
    for(int i=0;i<str.length();i++){
        if(str[i]==','){
            first=i;
            break;
        }
    }
    for(int i=str.length()-1;i>=0;i--){
        if(str[i]==','){
            last=i;
            break;
        
        }
    }
    cout<<str.substr(first+1)<<endl;
    cout<<str.substr(last+1)<<endl;

    return 0;
}

