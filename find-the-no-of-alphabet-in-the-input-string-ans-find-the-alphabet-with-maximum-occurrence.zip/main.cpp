/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<bits/stdc++.h> 
#define ASCII_SIZE 256 
using namespace std; 
  
char getMaxOccuringChar(char* str) 
{ 
    // Create array to keep the count of individual 
    // characters and initialize the array as 0 
    int count[ASCII_SIZE] = {0}; 
  
    // Construct character count array from the input 
    // string. 
    int len = strlen(str); 
    int max = 0;  // Initialize max count 
    char result;   // Initialize result 
  
    // Traversing through the string and maintaining 
    // the count of each character 
    for (int i = 0; i < len; i++) { 
        count[str[i]]++; 
        cout<<"no. of "<<str[i]<<"= "<<count[str[i]]<<endl;
        if (max < count[str[i]]) { 
            max = count[str[i]];
            result = str[i]; 
        } 
    } 
  
    return result; 
} 
int main() 
{ 
    char str[] = "sample string"; 
    cout << "Max occurring character is "
         << getMaxOccuringChar(str); 
} 