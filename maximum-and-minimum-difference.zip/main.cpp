/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*#include <iostream>
using namespace std; 
int func(int a[], int n){
    int max= a[1]-a[0];
    
    for(int i=0;i<n;i++){
        for(int j=i+1;j<n;j++){
            if(a[j]-a[i]>max){
                max= a[j]-a[i];
                
            }
        }
    }
    return max;
}
int main(){
    int n;
    cin>>n;
    int a[10];
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    cout<<"max difference: "<<func(a,n)<<endl;
    return 0;
}*/
 
#include <iostream>
using namespace std;
int main(){
    int n;
    int a[10];
    cin>>n;
    int i,j;
    for( i=0;i<n;i++){
        cin>>a[i];
    }
    int max=a[1]-a[0];
    for( i=0;i<n;i++){
        for(j=i+1;j<n;j++){
            if(a[j]-a[i]>max){
                max=a[j]-a[i];
            }
        }
    }
    cout<<max<<endl;
    for(i=0;i<n;i++){
        for(j=i+1;j<n;j++){
            if(a[j]-a[i]<max){
                max=a[j]-a[i];
            }
        }
    }
    cout<<max;
    return 0;
}
