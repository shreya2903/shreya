/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class Main{
    public static void main(String[] args){
        int n=10;
        double d= 10.00;
        char c= 'a';
        System.out.println(n);
        System.out.println(d);
        System.out.println(c);
    }
}
