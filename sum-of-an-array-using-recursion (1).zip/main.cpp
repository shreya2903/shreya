/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int findSum(int a[],int n){
    if(n<=0){
        return 0;
    }
    else
    return(findSum(a,n-1)+a[n-1]);
}
int main(){
    int a[10],i,n;
    cin>>n;
    for(i=0;i<n;i++){
        cin>>a[i];
    }
    cout<<"sum: "<<findSum(a,n);
}
